#!/bin/sh

if [ $# -eq 0 ]; then
	echo "./find_reloc <memory_address>"
	exit 1
fi

if [[ $1 != 0x* ]]; then
	echo "argument must start with 0x (hex number)"
	exit 1
fi 

#echo $1

printf -v addr_offset "%08X" "$(( $1 - 0x8804000 ))"

#echo ${addr_offset}

# .rel.text info from ghidra memory map (start address, length)
xxd -u -e -c4 -s 0x0033716c -l 0x000a0c30 bin/EBOOT.BIN.dec | grep ${addr_offset} | cut -d ' ' -f 1

echo "^^^^^^^^ (add +0x4 to the result)"


