
.definelabel SEC_HEADERSIZE,	(0x08804000 - 0x74)
// ghidra tooltip on .rel.text
.definelabel SEC_REL_TEXT,	0x0033716c
// .rel.text length is 0xa0c30

// free areas
.definelabel png_error,		0x08a8f308
.definelabel png_error_end,	0x08a8f40c
.definelabel png_error_size,	(png_error_end - png_error)

.definelabel png_warning,	0x08a8f40c
.definelabel png_warning_end,	0x08a8f654
.definelabel png_warning_size,	(png_warning_end - png_warning)

.definelabel update_left_analog,	0x08a7d910
.definelabel update_left_analog_end,	0x08a7d9b8
.definelabel update_left_analog_size,	(update_left_analog_end - update_left_analog)

// -------
.definelabel g_pad0,		0x08c2f578
.definelabel g_analog_data,	(g_pad0 + 0x50)

.definelabel g_player,		0x08c316c0

.definelabel analog_check,	0x08862f8c
.definelabel get_padstick_conf,	0x08863008

.definelabel update_roty,	0x08857234
.definelabel set_roty,		0x088f80dc
.definelabel is_pad_on_conf,	0x08862fa0

.definelabel g_dMin,		0x08b0edd0
.definelabel g_dMax,		0x08b0edd4

// ------------------------------------------------------
.open "bin/EBOOT.BIN.dec", "bin/EBOOT.BIN.patched.bin", 0
.psp
.headersize SEC_HEADERSIZE

// free areas
// ----------
.org png_error
.area png_error_size, 0
	jr ra
	nop
.importobj "../src/patch1.o"
.endarea

.org png_warning
.area png_warning_size, 0
	jr ra
	nop
.importobj "../src/patch2.o"
.endarea

.org update_left_analog
.area update_left_analog_size, 0
.importobj "../src/patch3.o"
.endarea

// every function wrap has to have a relocation underneath
// for the address of the place where function is called
//--------------------------

// check for both look up/down btns pressed
.org 0x08850fe4
	jal update_roty_wrap

// fix relocation ^
.orga (0x0034d714 + 4)
	.word 0


// checks if purge modifier (aka music note) is pressed
.org 0x0886338c
	jal is_note_pressed

// fix relocation ^
.orga (0x0035109c + 4)
	.word 0

// update both analog values
.org 0x08a7d6b8
	jal update_left_analog_wrap

// fix relocation ^
.orga (0x003cbefc + 0x4)
	.word 0

//-----------
// call analog_check_wrap, fix relocations

.org 0x08847008
	jal analog_check_wrap

// fix relocation ^
.orga (0x0034be44 + 4)
	.word 0

.org 0x088475ac
	jal analog_check_wrap

// fix relocation ^
.orga (0x0034bf1c + 4)
	.word 0

.org 0x08847f9c
	jal analog_check_wrap

// fix relocation ^
.orga (0x0034c15c + 4)
	.word 0

// inside rotx
.org 0x088532b4
	jal analog_check_wrap

// fix relocation ^
.orga (0x0034dd1c + 4)
	.word 0

.org 0x08853bd4
	jal analog_check_wrap

// fix relocation ^
.orga (0x0034ddf4 + 4)
	.word 0

// inside roty
.org 0x08857274
	jal analog_check_wrap

// fix relocation ^
.orga (0x0034e79c + 4)
	.word 0

.org 0x08858918
	jal analog_check_wrap

.orga (0x0034eaa4 + 4)
	.word 0

.org 0x08863064
	jal analog_check_wrap

.orga (0x00351024 + 4)
	.word 0

// this might not want to be enabled
.org 0x08863358
	jal analog_check_wrap

.orga (0x0035108c + 4)
	.word 0


.org 0x08863c00
	jal analog_check_wrap

.orga (0x003511d4 + 4)
	.word 0

.org 0x08864c98
	jal analog_check_wrap

.orga (0x00351404 + 4)
	.word 0

.org 0x08865ea0
	jal analog_check_wrap

.orga (0x0035170c + 4)
	.word 0

	/*
.org 0x088660d4
	jal analog_check_wrap

.orga (0x00351754 + 4)
	.word 0
	*/

.org 0x088664b8
	jal analog_check_wrap

.orga (0x003517c4 + 4)
	.word 0

.org 0x08869864
	jal analog_check_wrap

.orga (0x00352064 + 4)
	.word 0

.org 0x0886a140
	jal analog_check_wrap

.orga (0x00352174 + 4)
	.word 0

.org 0x0887377c
	jal analog_check_wrap

.orga (0x00353b9c + 4)
	.word 0

.org 0x08875bf4
	jal analog_check_wrap

.orga (0x00354324 + 4)
	.word 0



//-----------
// call get_padstick_conf_wrap, fix relocations

.org 0x08847020
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034be4c + 4)
	.word 0

.org 0x08847038
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034be54 + 4)
	.word 0

.org 0x08847050
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034be5c + 4)
	.word 0

.org 0x088475ec
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034bf24 + 4)
	.word 0

.org 0x08847600
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034bf2c + 4)
	.word 0

.org 0x08847614
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034bf34 + 4)
	.word 0

.org 0x08847628
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034bf3c + 4)
	.word 0

.org 0x08847fb8
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034c164 + 4)
	.word 0

// inside rotx
.org 0x088532d8
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034dd24 + 4)
	.word 0

// inside roty
.org 0x0885728c
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034e7a4 + 4)
	.word 0

.org 0x08858930
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034eaac + 4)
	.word 0

.org 0x08858944
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0034eab4 + 4)
	.word 0

.org 0x08863098
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x00351034 + 4)
	.word 0

.org 0x088630a8
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0035103c + 4)
	.word 0

.org 0x08869880
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0035206c + 4)
	.word 0

.org 0x08869894
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x00352074 + 4)
	.word 0

.org 0x0886a15c
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0035217c + 4)
	.word 0

.org 0x0886a170
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x00352184 + 4)
	.word 0

.org 0x08873794
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x00353ba4 + 4)
	.word 0

.org 0x088737a8
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x00353bac + 4)
	.word 0

.org 0x08875c0c
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x0035432c + 4)
	.word 0

.org 0x08875c20
	jal get_padstick_conf_wrap

// fix relocation ^
.orga (0x00354334 + 4)
	.word 0




// ---------------------------------
// relocations INSIDE the free areas
// fix relocations for update_left_analog
.orga (0x003cbf2c + 4)
	.word 0

.orga (0x003cbf34 + 4)
	.word 0


// fix relocations for png_error/png_warning and next 2 functions (used by those)
.orga (0x003ce95c + 4)
	.word 0

.orga (0x003ce964 + 4)
	.word 0

.orga (0x003ce96c + 4)
	.word 0

.orga (0x003ce974 + 4)
	.word 0

.orga (0x003ce984 + 4)
	.word 0

.orga (0x003ce97c + 4)
	.word 0

.orga (0x003ce98c + 4)
	.word 0

.orga (0x003ce99c + 4)
	.word 0

.orga (0x003ce994 + 4)
	.word 0

.orga (0x003ce9a4 + 4)
	.word 0

.orga (0x003ce9b4 + 4)
	.word 0

.orga (0x003ce9ac + 4)
	.word 0

.orga (0x003ce9bc + 4)
	.word 0

.orga (0x003ce9c4 + 4)
	.word 0

.orga (0x003ce9cc + 4)
	.word 0

.orga (0x003ce9d4 + 4)
	.word 0

.orga (0x003ce9e4 + 4)
	.word 0

.orga (0x003ce9dc + 4)
	.word 0

.orga (0x003ce9ec + 4)
	.word 0

.orga (0x003ce9fc + 4)
	.word 0

.orga (0x003ce9f4 + 4)
	.word 0

.orga (0x003cea04 + 4)
	.word 0

.orga (0x003cea14 + 4)
	.word 0

.orga (0x003cea0c + 4)
	.word 0

.orga (0x003cea1c + 4)
	.word 0


.close


