#include "../include/patch.h"

unsigned char analog_check_wrap(int param)
{
	if (GET_PLAYER_OFFSET(&g_player) == param)
		return 1;

	return analog_check(param);
}


int get_padstick_conf_wrap(int address, int axis)
{
	if (GET_PLAYER_OFFSET(&g_player) == address)
	{
		// Doesn't work :/
		//if (*(unsigned short*)address == 0) return 0;
		if ((*(unsigned short *)((char*)&g_player + 0x204c) & 0x3000) != 0) return 0;

		switch(axis)
		{
			case 0:
				return g_analog_data.lx;
				break;
			case 1:
				return g_analog_data.ly;
				break;
			case 2:
				return g_analog_data.rx;
				break;
			case 3:
				return -g_analog_data.ry;
				break;
			default:
				return 0;
		}
	}

	return get_padstick_conf(address, axis);
}

