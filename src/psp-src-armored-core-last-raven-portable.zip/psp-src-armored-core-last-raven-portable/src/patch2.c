
#include "../include/patch.h"

// this replaces a certain call that checks if purge button modifier is pressed
unsigned char is_note_pressed(unsigned short* btns, int mask)
{
	unsigned char res = (g_analog_data.lx == 1);

	if (res) return res;

	return  (is_pad_on_conf(btns, 8) && is_pad_on_conf(btns, 9) 
			&& is_pad_on_conf(btns, 0xa) && is_pad_on_conf(btns, 0xb));
}

// for Last Raven Portable, this wrap only checks for look reset
// (if both digital buttons look up + down are pressed)
void update_roty_wrap(int player)
{
	if ((player == (int)&g_player) && (*(char *)(*(int *)(player + 0x2600) + 0xb6) == -1))
	{
		unsigned short* addr = *(unsigned short **)(*(int *)(player + 0x2604) + 4);
		unsigned char btn_1 = is_pad_on_conf(addr, 0xa);
		unsigned char btn_2 = is_pad_on_conf(addr, 0xb);
		if (btn_1 && btn_2) // both buttons pressed
		{
			*(unsigned int*)(player + 0x1ff0) = 0;
			*(unsigned int*)(player + 0x2000) = 0;
			unsigned int res = set_roty(0.0f, g_dMin, g_dMax, (float*)(player + 0x1ff0));
			if (res)
				*(unsigned int*)(player + 0x2000) = 0;

			return;
		}
	}
	update_roty(player);
}
