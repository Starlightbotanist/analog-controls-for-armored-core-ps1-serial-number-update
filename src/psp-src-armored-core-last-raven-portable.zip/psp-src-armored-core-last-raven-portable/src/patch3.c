#include "../include/patch.h"

#define PSP_CTRL_NOTE   0x00800000

void update_left_analog_wrap(int gamepad, int paddata)
{
        if (paddata)
        {
                unsigned int btns = *(unsigned int*)(paddata + 4);

                /* the only way to have '1' in analog.lx is when music note button was pressed
                 * otherwise, values in analog.lx are either 0, or bigger than deadzone */
                char lx;

                if (btns & PSP_CTRL_NOTE) lx = 1;
                else
                {
                        lx = (*(char *)(paddata + 0x8) - 0x80);
                        if ((lx <= DEADZONE) && (lx >= -DEADZONE)) lx = 0;
                }

                *(char *)(gamepad + 0x50) = lx;
                *(char *)(gamepad + 0x51) = *(char *)(paddata + 0x9) - 0x80;
                *(char *)(gamepad + 0x52) = *(char *)(paddata + 0xA) - 0x80;
                *(char *)(gamepad + 0x53) = *(char *)(paddata + 0xB) - 0x80;
        }
        else // no paddata
        {
                *(unsigned int*)(gamepad + 0x50) = *(unsigned int*)(gamepad + 0xa4);
        }
}

