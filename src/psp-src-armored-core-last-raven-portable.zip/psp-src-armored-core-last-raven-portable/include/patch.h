#ifndef PATCH_H
#define PATCH_H

// lifted directly from the PS2 AC3-USA patch
typedef	char	s8;
typedef short	s16;
typedef int	s32;
typedef long	s64;

typedef	unsigned char	u8;
typedef unsigned short	u16;
typedef unsigned int	u32;
typedef unsigned long	u64;

#define DEADZONE 60
#define EXDEADZONE 115

// --------------------------------------------------------
extern void* g_player;

extern void update_left_analog(int gamepad, int paddata);

extern unsigned char analog_check(int param);
extern int get_padstick_conf(int address, int axis);
extern unsigned char is_pad_on_conf(unsigned short* address, int btn_mask);

extern void update_roty(int player);
extern unsigned int set_roty(float deltaY, float dMin, float dMax, float* pRotY);

extern float g_dMin, g_dMax;

/*
extern int update_rotx(float dMin, float dMax, void* player);
*/

extern unsigned short g_pad0;

struct dual_analog
{
	char lx;
	char ly;
	char rx;
	char ry;
};

extern struct dual_analog g_analog_data;

#define GET_ROTXY_CHECK(player)         (*(s8*)(*(s32*)(((u8*)player)+0x2600) + 0xb6))
#define GET_PLAYER_OFFSET(player)       (*(s32*)(*(s32*)(((u8*)player)+0x2604) + 0x4))

#endif

